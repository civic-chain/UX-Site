CIVIC-CHAIN PRESS KIT
=====================
As of November 6, 2026 · civic-chain.com · info@civic-chain.com

WHAT'S INSIDE
- README.txt .................. this file
- boilerplate.txt ............. short + long company descriptions
- civic-chain-fact-sheet.txt .. the fact sheet
- bios/ ....................... ~150-word bio per founder
- logos/ ...................... primary logo, mark, and social preview
- imagery/ .................... wide civic scenes for editorial use

USING THE LOGO
- Don't alter, recolor, stretch or add effects to the logo. Leave clear space
  around it at least the height of the mark's center link.
- Use the reversed (cream) logo on dark or photo backgrounds.
- Write the name "Civic-Chain" with the hyphen.
- Partner names and logos may be used only as shown on civic-chain.com/press.

MEDIA INQUIRIES
info@civic-chain.com - we reply within one business day. For demos and
interviews, include your outlet and deadline.

LEGAL
Civic-Chain is a software company. It does not hold municipal funds. Payments
are processed by Modern Treasury, and accounts-payable card payments are
processed by REPAY.

Civic-Chain partners with REPAY for payment processing. Not all payments on
Civic-Chain are processed by REPAY. All trademarks belong to their respective
owners.
